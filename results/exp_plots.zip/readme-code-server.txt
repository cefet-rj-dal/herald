ssh -p 49186 -L 9014:127.0.0.1:9014 rsalles5@aldebaran.eic.cefet-rj.br
#estabele o tunel entre tua maquina e o servidor na porta indicada
code-server password: rsalles5@code-server#2022
#uma vez logado, basta rodar code-server e acessa-lo pelo browser
